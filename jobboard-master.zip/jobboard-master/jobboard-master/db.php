<?php
    $con = mysqli_connect("localhost","root","","jobinfo");

    if(!$con){
        die("Connection Error");
    }
?>